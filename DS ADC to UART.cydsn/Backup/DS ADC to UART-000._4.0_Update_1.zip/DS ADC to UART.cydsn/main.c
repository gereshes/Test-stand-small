/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

volatile unsigned long _millis=0;

CY_ISR(millis_isr){
    _millis++;
    millis_interrupt_ClearPending();
}

unsigned long millis(){
    return _millis;
}
    
int main(void)
{
    int i=0;
    int reading=0;
    char text[256]="";
    CyGlobalIntEnable; /* Enable global interrupts. */
    millis_interrupt_StartEx(millis_isr);
    UART_Start();
    adc_Start();
    adc_StartConvert();
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        for(i=0; i<64; i++){
            adc_IsEndConversion(adc_WAIT_FOR_RESULT);
            reading += adc_GetResult32();
        }
        reading /= 64;
        reading = adc_CountsTo_uVolts(reading);
        snprintf(text, 256, "t=%ld \tv=%d\r\n", millis(), reading);
        UART_PutString(text);
    }
}

/* [] END OF FILE */
